package com.example.xioptimizer

import android.app.Activity
import android.content.SharedPreferences
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.core.view.WindowCompat

const val DYNAMIC = 99

val AccentPalette = listOf(
    "Синий" to Color(0xFF3B82F6),
    "Зелёный" to Color(0xFF22C55E),
    "Оранжевый" to Color(0xFFF97316),
    "Красный" to Color(0xFFEF4444),
    "Фиолетовый" to Color(0xFF8B5CF6),
    "Розовый" to Color(0xFFEC4899),
    "Бирюзовый" to Color(0xFF14B8A6),
    "Жёлтый" to Color(0xFFEAB308)
)

/** Настройки внешнего вида самого приложения. Всё сохраняется между запусками. */
class UiSettings(private val prefs: SharedPreferences) {

    /** 0 = как в системе, 1 = светлая, 2 = тёмная */
    var darkMode by mutableStateOf(prefs.getInt("dark_mode", 0))
        private set
    var accent by mutableStateOf(prefs.getInt("accent", 0))
        private set
    var amoled by mutableStateOf(prefs.getBoolean("amoled", false))
        private set
    var fontScale by mutableStateOf(prefs.getFloat("font_scale", 1f))
        private set
    var haptics by mutableStateOf(prefs.getBoolean("haptics", true))
        private set
    var riskUnlocked by mutableStateOf(prefs.getBoolean("risk_unlocked", false))
        private set

    fun updateDarkMode(v: Int) { darkMode = v; prefs.edit().putInt("dark_mode", v).apply() }
    fun updateAccent(v: Int) { accent = v; prefs.edit().putInt("accent", v).apply() }
    fun updateAmoled(v: Boolean) { amoled = v; prefs.edit().putBoolean("amoled", v).apply() }
    fun updateFontScale(v: Float) { fontScale = v; prefs.edit().putFloat("font_scale", v).apply() }
    fun updateHaptics(v: Boolean) { haptics = v; prefs.edit().putBoolean("haptics", v).apply() }
    fun updateRiskUnlocked(v: Boolean) { riskUnlocked = v; prefs.edit().putBoolean("risk_unlocked", v).apply() }

    fun resetLook() {
        updateDarkMode(0)
        updateAccent(0)
        updateAmoled(false)
        updateFontScale(1f)
        updateHaptics(true)
    }
}

@Composable
fun AppTheme(ui: UiSettings, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dark = when (ui.darkMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val accent = AccentPalette.getOrNull(ui.accent)?.second ?: AccentPalette[0].second

    var scheme = when {
        ui.accent == DYNAMIC && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> darkColorScheme(
            primary = accent, secondary = accent, tertiary = accent, onPrimary = Color.Black
        )
        else -> lightColorScheme(
            primary = accent, secondary = accent, tertiary = accent, onPrimary = Color.White
        )
    }
    if (dark && ui.amoled) {
        scheme = scheme.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceVariant = Color(0xFF161616)
        )
    }

    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        window.statusBarColor = scheme.background.toArgb()
        window.navigationBarColor = scheme.background.toArgb()
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !dark
        controller.isAppearanceLightNavigationBars = !dark
    }

    val density = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(density.density, ui.fontScale)) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
