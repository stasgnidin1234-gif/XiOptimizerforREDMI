package com.example.xioptimizer

import android.Manifest
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Выбор из нескольких вариантов, перенос на новую строку каждые perRow кнопок. */
@Composable
fun WrapChoiceRow(
    options: List<String>,
    selected: Int,
    perRow: Int = 3,
    onSelect: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.withIndex().chunked(perRow).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (i, label) ->
                    if (i == selected) {
                        Button(
                            onClick = { onSelect(i) },
                            contentPadding = PaddingValues(horizontal = 12.dp)
                        ) { Text(label, maxLines = 1) }
                    } else {
                        OutlinedButton(
                            onClick = { onSelect(i) },
                            contentPadding = PaddingValues(horizontal = 12.dp)
                        ) { Text(label, maxLines = 1) }
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun TurboStatusCard() {
    val context = LocalContext.current
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🎮 Game Turbo", style = MaterialTheme.typography.titleMedium)
            if (TurboState.active) {
                Text(
                    "Активен: ${TurboState.gameLabel}\n${TurboState.message}",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = { GameTurbo.requestStop(context) }) {
                    Text("Выключить и вернуть всё")
                }
            } else if (TurboState.pending) {
                Text(
                    "Turbo остался включённым (например, после перезагрузки), часть приложений всё ещё ограничена. " +
                        "Запусти Shizuku и нажми кнопку.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = { GameTurbo.restoreAsync(context) }) {
                    Text("Вернуть всё как было")
                }
            } else {
                Text(
                    "Выключен. Запусти игру из вкладки «Игры», и всё лишнее закроется на время игры.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun KeepAliveCard() {
    val context = LocalContext.current
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Чтобы Turbo не отключался сам", style = MaterialTheme.typography.titleSmall)
            Text(
                "MIUI любит закрывать фоновые сервисы. Открой настройки приложения и поставь " +
                    "«Экономия заряда» → «Нет ограничений», а также включи «Автозапуск».",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(onClick = {
                context.startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:${context.packageName}")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text("Открыть настройки приложения") }
        }
    }
}

@Composable
private fun GameCard(
    pkg: String,
    label: String,
    cfg: GameConfig,
    apps: List<Pair<String, String>>,
    canStart: Boolean,
    onStart: () -> Unit,
    onChange: (GameConfig) -> Unit,
    onRemove: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var keepQuery by remember { mutableStateOf("") }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = canStart, onClick = onStart) { Text("Запустить с Turbo") }
                OutlinedButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "Скрыть" else "⚙ Настройки")
                }
            }

            if (expanded) {
                if (pkg.startsWith("com.roblox.")) {
                    Text(
                        "Roblox на телефонах ограничен 60 FPS самим приложением, и снять это ограничение " +
                            "нельзя. Для ровной картинки Turbo ставит экран 60 Гц: 60 кадров на 90 Гц " +
                            "идут рывками.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(
                        onClick = {
                            onChange(
                                GameConfig(
                                    closeApps = true,
                                    dnd = true,
                                    gameMode = true,
                                    fps = 90,
                                    refreshHz = 90,
                                    fastAnim = true,
                                    noWifiScan = true,
                                    autoOffSec = 0,
                                    keep = cfg.keep,
                                    startCmds = cfg.startCmds,
                                    stopCmds = cfg.stopCmds
                                )
                            )
                        }
                    ) { Text("⚡ Roblox Extra (90)") }
                    Text(
                        "Extra: экран 90 Гц, просьба системе дать 90 FPS, максимум Turbo. Честно: сама игра " +
                            "почти наверняка останется на 60 кадрах, но экран и интерфейс будут на 90 Гц. " +
                            "Если картинка рвётся, вернись на «Рекомендованные».",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                OptionRow("Закрыть остальные приложения", cfg.closeApps) {
                    onChange(cfg.copy(closeApps = it))
                }
                OptionRow("Не беспокоить", cfg.dnd) { onChange(cfg.copy(dnd = it)) }
                OptionRow("Режим производительности игры", cfg.gameMode) {
                    onChange(cfg.copy(gameMode = it))
                }
                OptionRow("Быстрые анимации", cfg.fastAnim) { onChange(cfg.copy(fastAnim = it)) }
                OptionRow("Без фонового поиска Wi-Fi и Bluetooth", cfg.noWifiScan) {
                    onChange(cfg.copy(noWifiScan = it))
                }

                Text("Частота экрана", style = MaterialTheme.typography.titleSmall)
                WrapChoiceRow(
                    options = listOf("Не менять", "60 Гц", "90 Гц"),
                    selected = when (cfg.refreshHz) {
                        60 -> 1
                        90 -> 2
                        else -> 0
                    }
                ) { onChange(cfg.copy(refreshHz = listOf(0, 60, 90)[it])) }

                Text("Лимит FPS для игры", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Просьба к системе. Работает только в играх, которые это поддерживают (Android 12+).",
                    style = MaterialTheme.typography.bodySmall
                )
                WrapChoiceRow(
                    options = listOf("Не менять", "60", "90", "120"),
                    selected = when (cfg.fps) {
                        60 -> 1
                        90 -> 2
                        120 -> 3
                        else -> 0
                    },
                    perRow = 4
                ) { onChange(cfg.copy(fps = listOf(0, 60, 90, 120)[it])) }

                Text("Выключать Turbo после выхода из игры", style = MaterialTheme.typography.titleSmall)
                WrapChoiceRow(
                    options = listOf("Никогда", "10 сек", "1 мин", "5 мин"),
                    selected = when (cfg.autoOffSec) {
                        10 -> 1
                        60 -> 2
                        300 -> 3
                        else -> 0
                    },
                    perRow = 4
                ) { onChange(cfg.copy(autoOffSec = listOf(0, 10, 60, 300)[it])) }

                Text("Не закрывать эти приложения", style = MaterialTheme.typography.titleSmall)
                if (cfg.keep.isEmpty()) {
                    Text("Список пуст.", style = MaterialTheme.typography.bodySmall)
                }
                cfg.keep.toList().forEach { p ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            apps.firstOrNull { it.second == p }?.first ?: p,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        TextButton(onClick = { onChange(cfg.copy(keep = cfg.keep - p)) }) {
                            Text("✕")
                        }
                    }
                }
                OutlinedTextField(
                    value = keepQuery,
                    onValueChange = { keepQuery = it },
                    label = { Text("Добавить приложение в исключения") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (keepQuery.length >= 2) {
                    apps.filter {
                        (it.first.contains(keepQuery, ignoreCase = true) ||
                            it.second.contains(keepQuery, ignoreCase = true)) &&
                            it.second !in cfg.keep && it.second != pkg
                    }.take(5).forEach { (l, p) ->
                        TextButton(
                            onClick = {
                                onChange(cfg.copy(keep = cfg.keep + p))
                                keepQuery = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("＋ $l", maxLines = 1) }
                    }
                }

                Text("Свои команды (для опытных)", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Каждая строка выполняется через Shizuku. Пример: settings put global some_key 1",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = cfg.startCmds,
                    onValueChange = { onChange(cfg.copy(startCmds = it)) },
                    label = { Text("При запуске игры") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = cfg.stopCmds,
                    onValueChange = { onChange(cfg.copy(stopCmds = it)) },
                    label = { Text("При выключении Turbo") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onChange(GameConfig.recommended(pkg)) }) {
                        Text("Рекомендованные")
                    }
                    TextButton(onClick = onRemove) { Text("Убрать игру") }
                }
            }
        }
    }
}

@Composable
fun GamesTab(state: AppState, turbo: TurboPrefs) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    var detected by remember { mutableStateOf(emptySet<String>()) }
    var query by remember { mutableStateOf("") }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) {
            val list = loadApps(context)
            val pm = context.packageManager
            val games = list.filter { (_, pkg) ->
                try {
                    pm.getApplicationInfo(pkg, 0).category == ApplicationInfo.CATEGORY_GAME
                } catch (e: Exception) {
                    false
                }
            }.map { it.second }.toSet()
            apps = list
            detected = games
        }
    }

    val labels = apps.associate { it.second to it.first }
    val canStart = state.shizukuReady && !state.busy && !TurboState.active

    fun start(pkg: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        GameTurbo.launch(context, pkg)
    }

    val roblox = apps.firstOrNull { it.second.startsWith("com.roblox.") && it.second !in turbo.games }
    val suggestions = apps.filter {
        it.second in detected && it.second !in turbo.games && it != roblox
    }.take(10)
    val matches = if (query.length >= 2) {
        apps.filter {
            (it.first.contains(query, ignoreCase = true) ||
                it.second.contains(query, ignoreCase = true)) && it.second !in turbo.games
        }.take(6)
    } else {
        emptyList()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Игры и Game Turbo", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "У каждой игры свои настройки. Запускай игру отсюда: Turbo закроет лишнее и включит " +
                        "максимум, а вернуть всё можно кнопкой или из уведомления.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        item { ShizukuCard(state) }
        item { TurboStatusCard() }
        item { KeepAliveCard() }

        item { Text("Мои игры", style = MaterialTheme.typography.titleMedium) }

        if (turbo.games.isEmpty()) {
            item {
                Text(
                    "Пока пусто. Добавь игры ниже.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        items(turbo.games.toList().sortedBy { (labels[it] ?: it).lowercase() }) { pkg ->
            GameCard(
                pkg = pkg,
                label = labels[pkg] ?: pkg,
                cfg = turbo.config(pkg),
                apps = apps,
                canStart = canStart,
                onStart = { start(pkg) },
                onChange = { turbo.updateConfig(pkg, it) },
                onRemove = { turbo.removeGame(pkg) }
            )
        }

        item { Text("Добавить игру", style = MaterialTheme.typography.titleMedium) }

        if (roblox != null) {
            item {
                Button(
                    onClick = { turbo.addGame(roblox.second) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("＋ ${roblox.first} (с готовыми настройками)", maxLines = 1) }
            }
        }

        if (suggestions.isNotEmpty()) {
            item {
                Text(
                    "Найдено автоматически:",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            items(suggestions) { (label, pkg) ->
                TextButton(
                    onClick = { turbo.addGame(pkg) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("＋ $label", maxLines = 1) }
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Найти приложение по названию") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(matches) { (label, pkg) ->
            TextButton(
                onClick = {
                    turbo.addGame(pkg)
                    query = ""
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("＋ $label  ($pkg)", maxLines = 1) }
        }
    }
}
