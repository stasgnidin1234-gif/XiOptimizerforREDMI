package com.example.xioptimizer

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class AppAction(
    val title: String,
    val description: String,
    val risky: Boolean = false,
    val commands: (String) -> List<String>
)

private val appActions = listOf(
    AppAction("Остановить приложение", "Принудительно закрывает приложение.") {
        listOf("am force-stop $it")
    },
    AppAction(
        "Ограничить фон",
        "Запрещает работу в фоне и переводит в самую строгую группу ожидания. Уведомления могут перестать приходить."
    ) {
        listOf(
            "cmd appops set $it RUN_IN_BACKGROUND ignore",
            "am set-standby-bucket $it restricted"
        )
    },
    AppAction("Снять ограничение фона", "Возвращает обычную работу в фоне.") {
        listOf(
            "cmd appops set $it RUN_IN_BACKGROUND allow",
            "am set-standby-bucket $it active"
        )
    },
    AppAction(
        "Игровой режим: производительность",
        "Просит систему использовать режим производительности для этой игры (Android 12+)."
    ) {
        listOf("cmd game mode performance $it")
    },
    AppAction("Игровой режим: стандарт", "Возвращает стандартный режим для игры.") {
        listOf("cmd game mode standard $it")
    },
    AppAction(
        "Оптимизировать приложение",
        "Полная компиляция только этого приложения для более быстрого запуска."
    ) {
        listOf("cmd package compile -m speed -f $it")
    },
    AppAction("Включить приложение обратно", "Включает ранее отключённое приложение.") {
        listOf("pm enable $it")
    },
    AppAction(
        "Отключить приложение (заморозка)",
        "Приложение исчезает и не работает, данные остаются. Не отключай системные приложения, если не уверен.",
        risky = true
    ) {
        listOf("pm disable-user --user 0 $it")
    }
)

fun loadApps(context: Context): List<Pair<String, String>> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        .distinctBy { it.second }
        .sortedBy { it.first.lowercase() }
}

@Composable
fun AppsTab(state: AppState, ui: UiSettings) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.Default) { loadApps(context) }
    }

    val valid = Regex("[A-Za-z0-9_.]+").matches(query)
    val exact = apps.any { it.second == query }
    val matches = if (query.length >= 2 && !exact) {
        apps.filter {
            it.first.contains(query, ignoreCase = true) ||
                it.second.contains(query, ignoreCase = true)
        }.take(6)
    } else {
        emptyList()
    }
    val canRun = state.shizukuReady && !state.busy && valid && exact

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Управление приложениями", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Начни вводить название приложения и выбери его из списка.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        item { ShizukuCard(state) }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.trim() },
                label = { Text("Название или пакет") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(matches) { (label, pkg) ->
            TextButton(onClick = { query = pkg }, modifier = Modifier.fillMaxWidth()) {
                Text("$label  ($pkg)", maxLines = 1)
            }
        }
        if (exact) {
            item {
                Text(
                    "Выбрано: ${apps.first { it.second == query }.first}",
                    style = MaterialTheme.typography.titleSmall
                )
            }
        }

        items(appActions.filter { !it.risky || ui.riskUnlocked }) { action ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        (if (action.risky) "⚠ " else "") + action.title,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(action.description, style = MaterialTheme.typography.bodySmall)
                    Button(
                        enabled = canRun,
                        onClick = { state.run("${action.title}: $query", action.commands(query)) }
                    ) { Text("Выполнить") }
                }
            }
        }
    }
}
