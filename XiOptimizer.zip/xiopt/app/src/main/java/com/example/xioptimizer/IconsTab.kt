package com.example.xioptimizer

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Скрытое приложение. mode: 0 = убрана только иконка, 1 = приложение заморожено. */
data class HiddenIcon(
    val pkg: String,
    val label: String,
    val mode: Int,
    val comps: List<String>
)

/** Список скрытых иконок. Сохраняется, чтобы их всегда можно было вернуть. */
class HiddenIcons(private val prefs: SharedPreferences) {
    var items by mutableStateOf(load())
        private set
    var mode by mutableStateOf(prefs.getInt("icon_mode", 0))
        private set

    fun updateMode(v: Int) {
        mode = v
        prefs.edit().putInt("icon_mode", v).apply()
    }

    fun add(item: HiddenIcon) {
        items = items.filter { it.pkg != item.pkg } + item
        save()
    }

    fun remove(pkg: String) {
        items = items.filter { it.pkg != pkg }
        save()
    }

    private fun load(): List<HiddenIcon> = try {
        val arr = JSONArray(prefs.getString("hidden", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val comps = o.optJSONArray("comps")
            HiddenIcon(
                pkg = o.getString("pkg"),
                label = o.optString("label", o.getString("pkg")),
                mode = o.optInt("mode", 0),
                comps = if (comps == null) emptyList() else (0 until comps.length()).map { comps.getString(it) }
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun save() {
        val arr = JSONArray()
        items.forEach { h ->
            val o = JSONObject()
            o.put("pkg", h.pkg)
            o.put("label", h.label)
            o.put("mode", h.mode)
            o.put("comps", JSONArray(h.comps))
            arr.put(o)
        }
        prefs.edit().putString("hidden", arr.toString()).apply()
    }
}

private fun hideCommands(h: HiddenIcon): List<String> =
    if (h.mode == 0) {
        h.comps.map { "pm disable --user 0 '${h.pkg}/$it'" }
    } else {
        listOf("am force-stop ${h.pkg}", "pm disable-user --user 0 ${h.pkg}")
    }

private fun showCommands(h: HiddenIcon): List<String> =
    if (h.mode == 0) {
        h.comps.map { "pm enable --user 0 '${h.pkg}/$it'" }
    } else {
        listOf("pm enable ${h.pkg}")
    }

private fun launcherComponents(context: Context, pkg: String): List<String> {
    val intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setPackage(pkg)
    return context.packageManager.queryIntentActivities(intent, 0).map { it.activityInfo.name }
}

@Composable
fun IconsTab(state: AppState, hidden: HiddenIcons) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
    var loaded by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(hidden.items.size) {
        // после скрытия или возврата даём системе секунду обновить список
        if (loaded) delay(1200)
        apps = withContext(Dispatchers.Default) { loadApps(context) }
        loaded = true
    }

    val canRun = state.shizukuReady && !state.busy
    val hiddenPkgs = hidden.items.map { it.pkg }.toSet()
    val list = apps.filter {
        it.second !in hiddenPkgs && it.second != context.packageName &&
            (query.isBlank() ||
                it.first.contains(query, ignoreCase = true) ||
                it.second.contains(query, ignoreCase = true))
    }

    fun hide(label: String, pkg: String) {
        val mode = hidden.mode
        val comps = if (mode == 0) launcherComponents(context, pkg) else emptyList()
        if (mode == 0 && comps.isEmpty()) {
            state.run("Не нашёл иконку у приложения $label", emptyList())
            return
        }
        val item = HiddenIcon(pkg, label, mode, comps)
        hidden.add(item)
        state.run("Скрыто: $label", hideCommands(item))
    }

    fun show(h: HiddenIcon) {
        hidden.remove(h.pkg)
        state.run("Возвращено: ${h.label}", showCommands(h))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Иконки приложений", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Выбери, какие иконки убрать с экрана. Все скрытые приложения хранятся ниже, " +
                        "и любое можно вернуть.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        item { ShizukuCard(state) }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Способ скрытия", style = MaterialTheme.typography.titleSmall)
                    WrapChoiceRow(
                        options = listOf("Только иконка", "Заморозить"),
                        selected = hidden.mode,
                        perRow = 2
                    ) { hidden.updateMode(it) }
                    Text(
                        if (hidden.mode == 0) {
                            "Иконка исчезает с экрана и из списка приложений, а само приложение продолжает работать. " +
                                "Если у какого-то приложения не получится, выбери «Заморозить»."
                        } else {
                            "Приложение отключается полностью: исчезает иконка, оно не работает и не тратит ресурсы. " +
                                "Данные сохраняются."
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (hidden.items.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Скрытые (${hidden.items.size})",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        enabled = canRun,
                        onClick = { hidden.items.toList().forEach { show(it) } }
                    ) { Text("Вернуть все") }
                }
            }
            items(hidden.items, key = { it.pkg }) { h ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(h.label, style = MaterialTheme.typography.titleSmall)
                            Text(
                                if (h.mode == 0) "только иконка" else "заморожено",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Button(enabled = canRun, onClick = { show(h) }) { Text("Вернуть") }
                    }
                }
            }
        }

        item { Text("Все приложения", style = MaterialTheme.typography.titleMedium) }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Поиск") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(list, key = { it.second }) { (label, pkg) ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(label, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                        Text(pkg, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    OutlinedButton(enabled = canRun, onClick = { hide(label, pkg) }) {
                        Text("Скрыть")
                    }
                }
            }
        }
    }
}
