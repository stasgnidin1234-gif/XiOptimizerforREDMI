package com.example.xioptimizer

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Выполняет shell-команды с правами shell (uid 2000) через Shizuku. Root не нужен. */
object Shell {

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            if (isRunning()) Shizuku.requestPermission(1)
        } catch (_: Throwable) {
        }
    }

    /**
     * Shizuku.newProcess стал приватным в новых версиях API, поэтому вызываем через reflection.
     * Для более "правильного" варианта позже можно перейти на Shizuku UserService.
     */
    fun run(command: String): String {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            process.waitFor()
            (out + err).trim()
        } catch (e: Throwable) {
            "Ошибка: ${e.message}"
        }
    }
}
