package com.example.xioptimizer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Состояние Game Turbo для интерфейса. */
object TurboState {
    var active by mutableStateOf(false)
    var game by mutableStateOf("")
    var gameLabel by mutableStateOf("")
    var closed by mutableIntStateOf(0)
    var message by mutableStateOf("")

    /** Turbo остался включённым (например, после перезагрузки), но не восстановлен. */
    var pending by mutableStateOf(false)

    fun reset() {
        active = false
        game = ""
        gameLabel = ""
        closed = 0
        message = ""
        pending = false
    }
}

/** Настройки Game Turbo для одной игры. */
data class GameConfig(
    val closeApps: Boolean = true,
    val dnd: Boolean = true,
    val gameMode: Boolean = true,
    /** 0 = не просить, иначе просим систему ограничить игру этим FPS (работает не во всех играх). */
    val fps: Int = 0,
    /** 0 = не менять, 60 или 90. */
    val refreshHz: Int = 90,
    val fastAnim: Boolean = true,
    val noWifiScan: Boolean = true,
    /** 0 = никогда не выключать само, иначе через столько секунд вне игры. */
    val autoOffSec: Int = 0,
    /** Приложения, которые Turbo не закрывает. */
    val keep: Set<String> = emptySet(),
    val startCmds: String = "",
    val stopCmds: String = ""
) {
    fun toJson(): String {
        val o = JSONObject()
        o.put("closeApps", closeApps)
        o.put("dnd", dnd)
        o.put("gameMode", gameMode)
        o.put("fps", fps)
        o.put("refreshHz", refreshHz)
        o.put("fastAnim", fastAnim)
        o.put("noWifiScan", noWifiScan)
        o.put("autoOffSec", autoOffSec)
        o.put("keep", JSONArray(keep.toList()))
        o.put("startCmds", startCmds)
        o.put("stopCmds", stopCmds)
        return o.toString()
    }

    companion object {
        fun fromJson(s: String?, fallback: GameConfig): GameConfig {
            if (s.isNullOrBlank()) return fallback
            return try {
                val o = JSONObject(s)
                val arr = o.optJSONArray("keep")
                val keep = mutableSetOf<String>()
                if (arr != null) {
                    for (i in 0 until arr.length()) keep += arr.getString(i)
                }
                GameConfig(
                    closeApps = o.optBoolean("closeApps", true),
                    dnd = o.optBoolean("dnd", true),
                    gameMode = o.optBoolean("gameMode", true),
                    fps = o.optInt("fps", 0),
                    refreshHz = o.optInt("refreshHz", 90),
                    fastAnim = o.optBoolean("fastAnim", true),
                    noWifiScan = o.optBoolean("noWifiScan", true),
                    autoOffSec = o.optInt("autoOffSec", 0),
                    keep = keep,
                    startCmds = o.optString("startCmds", ""),
                    stopCmds = o.optString("stopCmds", "")
                )
            } catch (e: Exception) {
                fallback
            }
        }

        /**
         * Рекомендованные настройки. Roblox на телефонах ограничен 60 FPS самим приложением,
         * а 60 кадров на экране 90 Гц дают неровный ритм кадров, поэтому ставим 60 Гц.
         */
        fun recommended(pkg: String): GameConfig =
            if (pkg.startsWith("com.roblox.")) GameConfig(refreshHz = 60) else GameConfig()
    }
}

object GameConfigs {
    fun load(prefs: SharedPreferences, pkg: String): GameConfig =
        GameConfig.fromJson(prefs.getString("cfg_$pkg", null), GameConfig.recommended(pkg))

    fun save(prefs: SharedPreferences, pkg: String, cfg: GameConfig) {
        prefs.edit().putString("cfg_$pkg", cfg.toJson()).apply()
    }
}

/** Список игр и их настройки. Сохраняется между запусками. */
class TurboPrefs(private val prefs: SharedPreferences) {
    var games by mutableStateOf(prefs.getStringSet("games", emptySet())?.toSet() ?: emptySet())
        private set

    private val configs = mutableStateMapOf<String, GameConfig>().apply {
        games.forEach { put(it, GameConfigs.load(prefs, it)) }
    }

    fun config(pkg: String): GameConfig = configs[pkg] ?: GameConfigs.load(prefs, pkg)

    fun updateConfig(pkg: String, cfg: GameConfig) {
        configs[pkg] = cfg
        GameConfigs.save(prefs, pkg, cfg)
    }

    fun addGame(pkg: String) {
        games = games + pkg
        prefs.edit().putStringSet("games", games).apply()
        updateConfig(pkg, GameConfig.recommended(pkg))
    }

    fun removeGame(pkg: String) {
        games = games - pkg
        prefs.edit().putStringSet("games", games).remove("cfg_$pkg").apply()
        configs.remove(pkg)
    }
}

object GameTurbo {
    const val EXTRA_PKG = "pkg"
    const val ACTION_STOP = "com.example.xioptimizer.STOP_TURBO"

    /** Эти функции затрагивает Turbo, после выхода возвращаем то, что включил сам пользователь. */
    private val affected = listOf("anim_fast", "anim_off", "refresh_high", "refresh_60", "wifi_scan_off")

    private val neverTouch = setOf("moe.shizuku.privileged.api", "moe.shizuku.manager")

    fun launch(context: Context, pkg: String) {
        val intent = Intent(context, GameTurboService::class.java).putExtra(EXTRA_PKG, pkg)
        ContextCompat.startForegroundService(context, intent)
    }

    fun requestStop(context: Context) {
        context.startService(
            Intent(context, GameTurboService::class.java).setAction(ACTION_STOP)
        )
    }

    fun restoreAsync(context: Context) {
        val ctx = context.applicationContext
        Thread { restore(ctx) }.start()
    }

    private fun batch(commands: List<String>) {
        commands.chunked(25).forEach { Shell.run(it.joinToString("; ")) }
    }

    private fun tweak(id: String) = Tweaks.toggles.first { it.id == id }

    private fun runLines(text: String) {
        text.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { Shell.run(it) }
    }

    /** Сторонние приложения, которые закроем. Лаунчер, клавиатура, Shizuku, мы сами и список исключений остаются. */
    private fun findVictims(context: Context, game: String, extraKeep: Set<String>): Set<String> {
        val pm = context.packageManager
        val keep = mutableSetOf(game, context.packageName)
        keep += neverTouch
        keep += extraKeep
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        pm.queryIntentActivities(home, 0).forEach { keep += it.activityInfo.packageName }
        Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')
            ?.let { keep += it }
        return pm.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName !in keep }
            .map { it.packageName }
            .toSet()
    }

    /** Блокирующая функция: вызывать не из главного потока. */
    fun begin(context: Context, pkg: String) {
        val tp = context.getSharedPreferences("turbo", Context.MODE_PRIVATE)
        val cfg = GameConfigs.load(tp, pkg)
        val pm = context.packageManager
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

        val zen = Shell.run("settings get global zen_mode").trim().toIntOrNull() ?: 0
        val victims = if (cfg.closeApps) findVictims(context, pkg, cfg.keep) else emptySet()
        val twIds = buildList {
            if (cfg.fastAnim) add("anim_fast")
            if (cfg.refreshHz == 90) add("refresh_high")
            if (cfg.refreshHz == 60) add("refresh_60")
            if (cfg.noWifiScan) add("wifi_scan_off")
        }

        tp.edit()
            .putBoolean("active", true)
            .putString("game", pkg)
            .putStringSet("restricted", victims)
            .putInt("zen", zen)
            .putBoolean("dnd_used", cfg.dnd)
            .putStringSet("tw_ids", twIds.toSet())
            .putBoolean("gamemode_used", cfg.gameMode || cfg.fps > 0)
            .putInt("fps_used", cfg.fps)
            .putString("stop_cmds", cfg.stopCmds)
            .apply()

        TurboState.pending = false
        TurboState.game = pkg
        TurboState.gameLabel = label
        TurboState.closed = victims.size
        TurboState.active = true
        TurboState.message = "Готовлю телефон..."

        twIds.forEach { id -> tweak(id).apply.forEach { Shell.run(it) } }
        if (cfg.fps > 0) {
            Shell.run("cmd game set --mode performance --fps ${cfg.fps} $pkg")
        } else if (cfg.gameMode) {
            Shell.run("cmd game mode performance $pkg")
        }
        if (cfg.dnd) Shell.run("cmd notification set_dnd priority")
        Shell.run("cmd power set-fixed-performance-mode-enabled true")

        if (victims.isNotEmpty()) {
            TurboState.message = "Закрываю ${victims.size} приложений..."
            batch(victims.map { "am force-stop $it" })
            batch(victims.map { "cmd appops set $it RUN_IN_BACKGROUND ignore" })
        }
        Shell.run("am kill-all")
        runLines(cfg.startCmds)

        TurboState.message = "Запускаю игру. Закрыто приложений: ${victims.size}"
        Shell.run("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
        TurboState.message = "Turbo работает. Закрыто приложений: ${victims.size}"
    }

    /** Возвращает true, если всё восстановлено. Блокирующая функция. */
    fun restore(context: Context): Boolean {
        val tp = context.getSharedPreferences("turbo", Context.MODE_PRIVATE)
        if (!tp.getBoolean("active", false)) {
            TurboState.reset()
            return true
        }
        if (!Shell.hasPermission()) {
            TurboState.pending = true
            return false
        }

        TurboState.message = "Возвращаю всё как было..."
        val pkg = tp.getString("game", "") ?: ""
        val restricted = tp.getStringSet("restricted", emptySet()) ?: emptySet()
        val zen = tp.getInt("zen", 0)
        val twIds = tp.getStringSet("tw_ids", emptySet()) ?: emptySet()

        batch(restricted.map { "cmd appops set $it RUN_IN_BACKGROUND default" })
        if (tp.getBoolean("gamemode_used", false) && pkg.isNotEmpty()) {
            if (tp.getInt("fps_used", 0) > 0) {
                Shell.run("cmd game reset $pkg")
            } else {
                Shell.run("cmd game mode standard $pkg")
            }
        }
        Shell.run("cmd power set-fixed-performance-mode-enabled false")
        if (tp.getBoolean("dnd_used", false)) {
            val mode = when (zen) {
                1 -> "priority"
                2 -> "none"
                3 -> "alarms"
                else -> "off"
            }
            Shell.run("cmd notification set_dnd $mode")
        }
        if (twIds.isNotEmpty()) {
            twIds.forEach { id -> tweak(id).revert.forEach { Shell.run(it) } }
            val userPrefs = context.getSharedPreferences("tweaks", Context.MODE_PRIVATE)
            affected.forEach { id ->
                if (userPrefs.getBoolean(id, false)) tweak(id).apply.forEach { Shell.run(it) }
            }
        }
        runLines(tp.getString("stop_cmds", "") ?: "")

        tp.edit()
            .putBoolean("active", false)
            .remove("restricted")
            .remove("game")
            .apply()
        TurboState.reset()
        return true
    }

    /** true / false, а если определить не удалось (например, Shizuku недоступен), то null. */
    fun inForeground(pkg: String): Boolean? {
        val out = Shell.run("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        if (out.isBlank() || out.startsWith("Ошибка")) return null
        return out.contains(pkg)
    }
}

class GameTurboService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    @Volatile
    private var stopRequested = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showForeground("Game Turbo запускается...")

        if (intent?.action == GameTurbo.ACTION_STOP) {
            if (job?.isActive == true) {
                stopRequested = true
            } else {
                scope.launch { finish() }
            }
            return START_NOT_STICKY
        }

        val pkg = intent?.getStringExtra(GameTurbo.EXTRA_PKG)
        if (pkg == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (job?.isActive == true) return START_NOT_STICKY

        running = true
        stopRequested = false
        job = scope.launch {
            val cfg = GameConfigs.load(getSharedPreferences("turbo", Context.MODE_PRIVATE), pkg)
            GameTurbo.begin(applicationContext, pkg)
            updateNotification(
                if (cfg.autoOffSec > 0) {
                    "Turbo: ${TurboState.gameLabel}. Выключится сам после выхода из игры."
                } else {
                    "Turbo: ${TurboState.gameLabel}. Работает, пока не выключишь."
                }
            )

            // сколько проверок (раз в 2 секунды) вне игры до автовыключения; 0 = никогда
            val needAway = if (cfg.autoOffSec > 0) maxOf(1, cfg.autoOffSec / 2) else 0
            val power = getSystemService(PowerManager::class.java)
            val startedAt = System.currentTimeMillis()
            var seen = false
            var away = 0
            var tick = 0

            while (isActive && !stopRequested) {
                delay(1000)
                tick++
                if (needAway == 0 || tick % 2 != 0) continue
                if (!power.isInteractive) {
                    away = 0
                    continue
                }
                val fg = GameTurbo.inForeground(pkg) ?: continue
                if (fg) {
                    seen = true
                    away = 0
                } else if (seen || System.currentTimeMillis() - startedAt > 45_000) {
                    away++
                }
                if (away >= needAway) break
            }
            finish()
        }
        return START_NOT_STICKY
    }

    private fun finish() {
        GameTurbo.restore(applicationContext)
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        val ctx = applicationContext
        if (ctx.getSharedPreferences("turbo", Context.MODE_PRIVATE).getBoolean("active", false)) {
            Thread { GameTurbo.restore(ctx) }.start()
        }
        super.onDestroy()
    }

    private fun buildNotification(text: String) = run {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel("turbo", "Game Turbo", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, GameTurboService::class.java).setAction(GameTurbo.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        NotificationCompat.Builder(this, "turbo")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Game Turbo")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Выключить", stop)
            .build()
    }

    private fun showForeground(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, 1, buildNotification(text), type)
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
    }

    companion object {
        @Volatile
        var running = false
    }
}
